Week JSON files defining playlists, characters, and colors live here.
