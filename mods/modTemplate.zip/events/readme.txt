Add custom event logic (.hx/.lua) and their matching .txt descriptions for the Chart Editor here.
