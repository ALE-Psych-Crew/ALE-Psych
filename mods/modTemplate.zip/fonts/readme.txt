Place custom font files (TTF/OTF/FNT) that you plan to load through Paths.font in UI scripts.
