Fragment/vertex shader files for post-processing or sprite materials live here.
