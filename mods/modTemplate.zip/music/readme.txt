Menu, pause, and other non-song music loops (OGG/MP3) go here.
