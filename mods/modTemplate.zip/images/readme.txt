Keep every PNG/atlas folder used for sprites, UI, and menu art inside this directory.
