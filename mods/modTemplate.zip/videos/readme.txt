MP4 cutscene or story videos belong in this folder.
