Drop character JSON files and optional scripts for playable, opponent, or gf variants here.
