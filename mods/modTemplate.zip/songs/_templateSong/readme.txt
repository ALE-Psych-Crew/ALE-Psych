Duplicate this folder when creating a new track to keep its structure consistent.
