Put Inst.ogg, Voices.ogg, or split vocal tracks for this song in this folder.
