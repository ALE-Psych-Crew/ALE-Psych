Difficulty JSON files and optional events.json for the song belong here.
