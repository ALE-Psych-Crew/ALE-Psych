Each song gets its own folder (see _templateSong) containing charts, music, and dialogue.
