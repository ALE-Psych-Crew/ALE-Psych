Shared Lua modules meant to be required from other scripts go into this folder.
