Reusable HScript classes/modules that other scripts import live here.
