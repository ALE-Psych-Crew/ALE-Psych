Custom substate scripts (pause, game over, popups) should be stored in this folder.
