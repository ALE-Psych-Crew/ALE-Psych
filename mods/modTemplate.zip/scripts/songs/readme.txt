Global song scripts that run for every track (like default song-wide hooks) go here.
