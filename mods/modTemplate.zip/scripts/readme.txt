Global Lua/HScript files that the engine can load automatically belong here.
