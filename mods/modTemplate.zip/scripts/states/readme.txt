Custom FlxState scripts you want to switch to (menus, gameplay variants) belong here.
