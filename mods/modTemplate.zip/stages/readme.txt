Stage JSON/HScript definitions and helper scripts should be placed here.
