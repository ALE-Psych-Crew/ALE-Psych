Short sound effects (hitsounds, menu clicks, ambience) live in this directory.
