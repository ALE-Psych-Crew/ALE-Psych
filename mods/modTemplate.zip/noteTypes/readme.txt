Create custom note type definitions (.txt plus optional scripts) in this folder.
